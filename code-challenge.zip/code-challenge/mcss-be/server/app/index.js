// -------- Services, Routes, Utils --------
const { express, expressService } = require(`${global.SERVER_ROOT}/libs/services/express-service`)
const serveNotFoundApiRoutes = require(`${global.SERVER_ROOT}/libs/utils/serve-not-found-api-routes-util`)
const cors = require('cors')
const apiRoutes = require('./routes')

// -------- Configure Express Server --------
module.exports = function expressApp () {
  const app = expressService(express)
  app.use(cors())
  app.use(apiRoutes)
  serveNotFoundApiRoutes(app)
  return app
}
