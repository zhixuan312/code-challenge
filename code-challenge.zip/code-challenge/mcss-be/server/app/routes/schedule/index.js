// -------- Essential Packages --------
const express = require('express')
const router = express.Router({ mergeParams: true })

// -------- Controllers --------
const getOneScheduleController = require('./get-one-schedule/controller')
const getAvailableSchedulesController = require('./get-available-schedules/controller')
const getAllSchedulesController = require('./get-all-schedules/controller')
const createScheduleController = require('./create-schedule/controller')
const updateScheduleController = require('./update-schedule/controller')
const deleteScheduleController = require('./delete-schedule/controller')

// -------- API Endpoints --------
router.post('/', createScheduleController)
router.get('/available', getAvailableSchedulesController)
router.get('/:scheduleId', getOneScheduleController)
router.get('/', getAllSchedulesController)
router.put('/:scheduleId', updateScheduleController)
router.delete('/:scheduleId', deleteScheduleController)

module.exports = router
