const respond = require(`${global.SERVER_ROOT}/libs/utils/response-util`) // Used for giving standardized responses
const knexConnection = require(`${global.SERVER_ROOT}/libs/services/knex-service`)
const scheduleModel = require('../model')
const validateRequest = require('./helpers/validation')

module.exports = async (req, res) => {
  const knex = knexConnection()
  try {
    // step 1: validate request
    const requestParams = validateRequest(req)

    // step 2: check RBAC
    await scheduleModel.checkAccessControl(req, knex, requestParams.authorization)

    // step 3: delete schedule
    await scheduleModel.deleteSchedule(knex, requestParams.scheduleId)

    respond.success(res)
  } catch (error) { respond.failure(res, error) } finally { knex.destroy() }
}
