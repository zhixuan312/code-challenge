const respond = require(`${global.SERVER_ROOT}/libs/utils/response-util`) // Used for giving standardized responses
const knexConnection = require(`${global.SERVER_ROOT}/libs/services/knex-service`)
const scheduleModel = require('../model')
const validateRequest = require('./helpers/validation')
const generateAvailableSchedule = require('./helpers/generateAvailableSchedule')

module.exports = async (req, res) => {
  const knex = knexConnection()
  try {
    // step 1: validate request
    const requestParams = validateRequest(req)

    // step 2: check RBAC
    const decodedToken = await scheduleModel.checkAccessControl(req, knex, requestParams.authorization)

    // step 3: retrieve available schedules
    const userSchedules = await scheduleModel.getAllSchedules(knex)

    // step 4: generate template schedules
    const finalSchedule = await generateAvailableSchedule(requestParams.date, userSchedules, decodedToken.email, decodedToken.role)

    respond.success(res, finalSchedule)
  } catch (error) { respond.failure(res, error) } finally { knex.destroy() }
}
