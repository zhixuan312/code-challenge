const source = 'routes_schedule_getAvailableSchedules_generateAvailableSchedule'
const { SystemFunctionError } = require(`${global.SERVER_ROOT}/libs/utils/response-util/errortypes`)
const moment = require('moment')
const _ = require('lodash')
const { SHOP_ENUM, ACTIVITY_CUSTOMER_ENUM, ACTIVITY_ADMIN_ENUM, USER_ROLE_ENUM, STYLIST_ENUM } = require('../../model/helpers/constant')

module.exports = async (date, userSchedules, email, role) => {
  try {
    const template = []
    const searchDate = moment(date)

    const activityEnum = USER_ROLE_ENUM.admin === role ? ACTIVITY_ADMIN_ENUM : ACTIVITY_CUSTOMER_ENUM
    const stylistEnum = USER_ROLE_ENUM.admin === role ? { stylist1: email } : STYLIST_ENUM
    for (let activityIndex = 0; activityIndex < Object.keys(activityEnum).length; activityIndex++) {
      for (let stylistIndex = 0; stylistIndex < Object.keys(stylistEnum).length; stylistIndex++) {
        for (let hourIndex = 0; hourIndex < 8; hourIndex++) {
          for (let shopIndex = 0; shopIndex < Object.keys(SHOP_ENUM).length; shopIndex++) {
            const scheduleTemplate = {
              day: searchDate.format('dddd'),
              date: searchDate.format('YYYY-MM-DD'),
              time: `${hourIndex + 10}:00`,
              shop: SHOP_ENUM[`shop${shopIndex + 1}`],
              activity: activityEnum[`activity${activityIndex + 1}`],
              stylist: STYLIST_ENUM[`stylist${stylistIndex + 1}`]
            }
            const occupiedSlot = _.find(userSchedules, record => { return moment(record.slotDate).format('YYYY-MM-DD HH:mm') === `${scheduleTemplate.date} ${scheduleTemplate.time}` })
            if (!occupiedSlot) template.push(scheduleTemplate)
          }
        }
      }
    }

    return template
  } catch (error) {
    console.log(`source: ${source}\n ${error.stack}`)
    throw new SystemFunctionError(error.message)
  }
}
