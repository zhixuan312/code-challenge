const validateRequest = require(`${global.SERVER_ROOT}/libs/utils/validation-util`)

module.exports = (reqBody) => {
  const schema = {
    headers: {
      authorization: { type: 'string' }
    },
    query: {
      $$strict: true
    }
  }
  return validateRequest(reqBody, schema)
}
