const validateRequest = require(`${global.SERVER_ROOT}/libs/utils/validation-util`)

module.exports = (reqBody) => {
  const schema = {
    headers: {
      authorization: { type: 'string' }
    },
    query: {
      $$strict: true,
      duration: { type: 'number', min: 1, max: 12 }
    }
  }
  return validateRequest(reqBody, schema)
}
