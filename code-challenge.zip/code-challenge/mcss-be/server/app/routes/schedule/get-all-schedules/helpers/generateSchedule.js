const source = 'routes_schedule_getAvailableSchedules_generateSchedule'
const { SystemFunctionError } = require(`${global.SERVER_ROOT}/libs/utils/response-util/errortypes`)
const moment = require('moment')
const _ = require('lodash')
const { USER_ROLE_ENUM } = require('../../model/helpers/constant')

module.exports = (scheduleDuration, userSchedules, email, role) => {
  try {
    const template = []
    const dayOfWeek = moment().utcOffset('+0800').format('e')
    let startCount = dayOfWeek === '0' ? 6 : dayOfWeek - 1

    for (let weekIndex = 0; weekIndex < scheduleDuration; weekIndex++) {
      template.push([])
      for (let dayIndex = 0; dayIndex < 7; dayIndex++) {
        const date = moment().subtract(startCount, 'days').utcOffset('+0800')
        template[weekIndex].push([])
        for (let hourIndex = 0; hourIndex < 8; hourIndex++) {
          const scheduleTemplate = {
            day: date.format('dddd'),
            date: date.format('YYYY-MM-DD'),
            time: `${hourIndex + 10}:00`
          }
          const occupiedSlot = _.find(userSchedules, record => { return moment(record.slotDate).format('YYYY-MM-DD HH:mm') === `${scheduleTemplate.date} ${scheduleTemplate.time}` })
          if (occupiedSlot) {
            if (role === USER_ROLE_ENUM.admin) scheduleTemplate.occupier = occupiedSlot.creatorEmail
            else scheduleTemplate.occupier = occupiedSlot.creatorEmail === email ? 'Me' : 'Others'
            scheduleTemplate.stylistEmail = occupiedSlot.stylistEmail
            scheduleTemplate.activity = occupiedSlot.activity
            scheduleTemplate.shop = occupiedSlot.shop
            scheduleTemplate.id = occupiedSlot.id
          }
          template[weekIndex][dayIndex].push(scheduleTemplate)
        }
        startCount--
      }
    }

    return template
  } catch (error) {
    console.log(`source: ${source}\n ${error.stack}`)
    throw new SystemFunctionError(error.message)
  }
}
