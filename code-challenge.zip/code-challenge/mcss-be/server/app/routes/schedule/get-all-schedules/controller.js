const respond = require(`${global.SERVER_ROOT}/libs/utils/response-util`) // Used for giving standardized responses
const knexConnection = require(`${global.SERVER_ROOT}/libs/services/knex-service`)
const scheduleModel = require('../model')
const validateRequest = require('./helpers/validation')
const generateSchedule = require('./helpers/generateSchedule')

module.exports = async (req, res) => {
  const knex = knexConnection()
  try {
    // step 1: validate request
    if (req.query.duration) req.query.duration = Number(req.query.duration)
    const requestParams = validateRequest(req)

    // step 2: check RBAC
    const decodedToken = await scheduleModel.checkAccessControl(req, knex, requestParams.authorization)

    // step 3: retrieve all schedules
    const userSchedules = await scheduleModel.getAllSchedules(knex)

    // step 4: generate template schedules
    const finalSchedule = generateSchedule(requestParams.duration, userSchedules, decodedToken.email, decodedToken.role)

    respond.success(res, finalSchedule)
  } catch (error) { respond.failure(res, error) } finally { knex.destroy() }
}
