const respond = require(`${global.SERVER_ROOT}/libs/utils/response-util`) // Used for giving standardized responses
const knexConnection = require(`${global.SERVER_ROOT}/libs/services/knex-service`)
const scheduleModel = require('../model')
const validateRequest = require('./helpers/validation')
const moment = require('moment')

module.exports = async (req, res) => {
  const knex = knexConnection()
  try {
    // step 1: validate request
    const requestParams = validateRequest(req)

    // step 2: check RBAC
    await scheduleModel.checkAccessControl(req, knex, requestParams.authorization)

    // step 3: update schedule
    const updatedSchedule = {}
    if (requestParams.activity) updatedSchedule.activity = requestParams.activity
    if (requestParams.stylistEmail) updatedSchedule.stylist_email = requestParams.stylistEmail
    if (requestParams.shop) updatedSchedule.shop = requestParams.shop
    if (Object.keys(requestParams).length > 0) updatedSchedule.last_modified_date = moment().format('YYYY-MM-DD HH:mm:ss')
    const request = await scheduleModel.updateSchedule(knex, requestParams.scheduleId, updatedSchedule)

    respond.success(res, request)
  } catch (error) { respond.failure(res, error) } finally { knex.destroy() }
}
