const validateRequest = require(`${global.SERVER_ROOT}/libs/utils/validation-util`)

module.exports = (reqBody) => {
  const schema = {
    headers: {
      authorization: { type: 'string' }
    },
    query: {
      $$strict: true
    },
    body: {
      $$strict: true,
      activity: { type: 'string', min: 1, optional: true },
      shop: { type: 'string', optional: true },
      stylistEmail: { type: 'email', optional: true }
    }
  }
  return validateRequest(reqBody, schema)
}
