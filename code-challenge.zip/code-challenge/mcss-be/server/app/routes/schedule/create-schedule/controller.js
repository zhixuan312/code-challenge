const respond = require(`${global.SERVER_ROOT}/libs/utils/response-util`) // Used for giving standardized responses
const knexConnection = require(`${global.SERVER_ROOT}/libs/services/knex-service`)
const scheduleModel = require('../model')
const validateRequest = require('./helpers/validation')
const uuid = require('uuid/v4')

module.exports = async (req, res) => {
  const knex = knexConnection()
  try {
    // step 1: validate request
    const requestParams = validateRequest(req)

    // step 2: check RBAC
    const decodedToken = await scheduleModel.checkAccessControl(req, knex, requestParams.authorization)

    // step 3: prepare new schedule
    const createSchedule = {
      id: uuid(),
      slot_date: requestParams.slotDate,
      creator_email: decodedToken.email,
      stylist_email: requestParams.stylistEmail,
      activity: requestParams.activity,
      shop: requestParams.shop
    }

    // step 4: check availablility

    // step 5: create schedule
    const schedule = await scheduleModel.createSchedule(knex, createSchedule)

    respond.success(res, schedule)
  } catch (error) { respond.failure(res, error) } finally { knex.destroy() }
}
