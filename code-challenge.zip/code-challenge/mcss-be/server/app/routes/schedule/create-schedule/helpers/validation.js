const validateRequest = require(`${global.SERVER_ROOT}/libs/utils/validation-util`)

module.exports = (reqBody) => {
  console.log(new Date())
  const schema = {
    headers: {
      authorization: { type: 'string' }
    },
    query: {
      $$strict: true
    },
    body: {
      $$strict: true,
      slotDate: { type: 'string', min: 1 },
      creatorEmail: { type: 'email' },
      stylistEmail: { type: 'email' },
      activity: { type: 'string', min: 1 },
      shop: { type: 'string', min: 1 }
    }
  }
  return validateRequest(reqBody, schema)
}
