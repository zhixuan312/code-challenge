const source = 'routes_schedule_model_getAllSchedule'
const { PostgresError } = require(`${global.SERVER_ROOT}/libs/utils/response-util/errortypes`)

module.exports = async (knex) => {
  try {
    const scheduleResult = await knex
      .select(['id', 'slot_date AS slotDate', 'creator_email AS creatorEmail', 'activity', 'stylist_email AS stylistEmail', 'shop'])
      .from(('schedule'))
    if (scheduleResult.length === 0) throw new Error('invalid schedule')
    return scheduleResult
  } catch (error) {
    console.log(`source: ${source}\n ${error.stack}`)
    throw new PostgresError(error.message)
  }
}
