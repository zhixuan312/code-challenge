const source = 'routes_schedule_model_checkSlotAvailability'
const { PostgresError } = require(`${global.SERVER_ROOT}/libs/utils/response-util/errortypes`)

module.exports = async (knex, schedule) => {
  try {
    if (schedule) return true
    return false
  } catch (error) {
    console.log(`source: ${source}\n ${error.stack}`)
    throw new PostgresError(error.message)
  }
}
