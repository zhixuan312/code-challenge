const source = 'routes_schedule_model_getOneSchedule'
const { PostgresError } = require(`${global.SERVER_ROOT}/libs/utils/response-util/errortypes`)

module.exports = async (knex, scheudleId) => {
  try {
    const scheduleResult = await knex
      .select(['id', 'slot_date AS slotDate', 'creator_email AS creatorEmail', 'activity', 'stylist_email AS stylistEmail', 'shop', 'last_modified_date AS lastModifiedDate'])
      .from(('schedule'))
      .where('id', '=', scheudleId)
      .limit(1)
    if (scheduleResult.length === 0) throw new Error('invalid schedule id')
    return scheduleResult[0]
  } catch (error) {
    console.log(`source: ${source}\n ${error.stack}`)
    throw new PostgresError(error.message)
  }
}
