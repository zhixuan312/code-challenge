const source = 'routes_schedule_model_deleteSchedule'
const { PostgresError } = require(`${global.SERVER_ROOT}/libs/utils/response-util/errortypes`)

module.exports = async (knex, scheduleId) => {
  try {
    const scheduleResult = await knex('schedule')
      .where('id', '=', scheduleId)
      .delete()
    if (scheduleResult.length === 0) throw new Error('fail to delete')
  } catch (error) {
    console.log(`source: ${source}\n ${error.stack}`)
    throw new PostgresError(error.message)
  }
}
