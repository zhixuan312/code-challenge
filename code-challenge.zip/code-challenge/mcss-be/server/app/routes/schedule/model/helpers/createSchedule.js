const source = 'routes_schedule_model_createSchedule'
const { PostgresError } = require(`${global.SERVER_ROOT}/libs/utils/response-util/errortypes`)

module.exports = async (knex, schedule) => {
  try {
    const scheduleResult = await knex('schedule')
      .insert(schedule, ['id', 'slot_date AS slotDate', 'creator_email AS creatorEmail', 'activity', 'stylist_email AS stylistEmail', 'shop'])
    return scheduleResult[0]
  } catch (error) {
    console.log(`source: ${source}\n ${error.stack}`)
    throw new PostgresError(error.message)
  }
}
