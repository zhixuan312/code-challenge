const source = 'routes_schedule_model_getAllSchedule'
const { PostgresError } = require(`${global.SERVER_ROOT}/libs/utils/response-util/errortypes`)

module.exports = async (knex, scheduleId, updatedRequest) => {
  try {
    const scheduleResult = await knex('schedule')
      .where('id', '=', scheduleId)
      .update(updatedRequest, ['id', 'slot_date AS slotDate', 'creator_email AS creatorEmail', 'activity', 'stylist_email AS stylistEmail', 'shop'])
    if (scheduleResult.length === 0) throw new Error('invalid schedule')
    return scheduleResult[0]
  } catch (error) {
    console.log(`source: ${source}\n ${error.stack}`)
    throw new PostgresError(error.message)
  }
}
