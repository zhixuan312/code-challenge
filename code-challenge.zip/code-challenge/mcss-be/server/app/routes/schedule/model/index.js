module.exports = {
  // create
  createSchedule: require('./helpers/createSchedule'),
  // retrieve
  getOneSchedule: require('./helpers/getOneSchedule'),
  getAllSchedules: require('./helpers/getAllSchedules'),
  getAllSchedulesByEmail: require('./helpers/getAllSchedulesByEmail'),
  // update
  updateSchedule: require('./helpers/updateSchedule'),
  // delete
  deleteSchedule: require('./helpers/deleteScheldule'),
  // others
  checkAccessControl: require('./helpers/checkAccessControl'),
  checkSlotAvailability: require('./helpers/checkSlotAvailability'),
  getRoleByEmail: require('./helpers/getRoleByEmail')
}
