const source = 'routes_schedule_model_getRoleByEmail'
const { PostgresError } = require(`${global.SERVER_ROOT}/libs/utils/response-util/errortypes`)

module.exports = async (knex, email) => {
  try {
    const userResult = await knex
      .select()
      .from(('user'))
      .where('email', '=', email)
      .limit(1)
    if (userResult.length === 0) throw new Error('invalid user email')
    return userResult[0].role
  } catch (error) {
    console.log(`source: ${source}\n ${error.stack}`)
    throw new PostgresError(error.message)
  }
}
