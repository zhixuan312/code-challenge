const USER_ROLE_ENUM = {
  admin: 'admin',
  normal: 'normal'
}

const SHOP_ENUM = {
  shop1: 'VivoCity',
  shop2: 'Orchard ION',
  shop3: 'Tampines Mall',
  shop4: 'Jurong Point',
  shop5: 'Nex'
}

const ACTIVITY_CUSTOMER_ENUM = {
  activity1: 'Perm',
  activity2: 'Cut',
  activity3: 'Color',
  activity4: 'Rebonding',
  activity5: 'Bleach'
}

const ACTIVITY_ADMIN_ENUM = {
  activity1: 'PH',
  activity2: 'MC',
  activity3: 'AL',
  activity4: 'Others'
}

const STYLIST_ENUM = {
  stylist1: 'zhang.zhixuan@gmail.com',
  stylist2: 'kenneth.phooi@gmail.com',
  stylist3: 'johnervan.lee@gmail.com'
}

module.exports = {
  USER_ROLE_ENUM,
  SHOP_ENUM,
  ACTIVITY_CUSTOMER_ENUM,
  ACTIVITY_ADMIN_ENUM,
  STYLIST_ENUM
}
