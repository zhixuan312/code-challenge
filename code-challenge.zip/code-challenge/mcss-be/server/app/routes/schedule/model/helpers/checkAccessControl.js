const source = 'routes_schedule_model_checkAccessControl'
const { AccessTokenError } = require(`${global.SERVER_ROOT}/libs/utils/response-util/errortypes`)
const _ = require('lodash')
const jwtDecode = require('jwt-decode')
const moment = require('moment')

module.exports = async (req, knex, token) => {
  try {
    const decodedToken = jwtDecode(token.split(' ')[1])

    const expiration = moment().isBefore(moment(decodedToken.exp))
    if (!expiration) throw new AccessTokenError()

    const reqColumns = [decodedToken.role]
    const reqRow = { url: req.route.path, method: req.method }

    const checkResult = _.map(reqColumns, col => { return check(reqRow, { role: col }) })
    if (!_.includes(checkResult, 1)) throw new AccessTokenError()
    return decodedToken
  } catch (error) {
    console.log(`source: ${source}\n ${error.stack}`)
    throw new AccessTokenError('user is not allowed to access this endpoint')
  }
}

function check (reqRow, reqColumn) {
  const row = [
    { url: '/', method: 'GET' }, // getAllSchedule
    { url: '/available', method: 'GET' }, // getAvailableSchedule
    { url: '/:scheduleId', method: 'GET' }, // getOneSchedule
    { url: '/', method: 'POST' }, // createSchedule
    { url: '/:scheduleId', method: 'PUT' }, // updateSchedule
    { url: '/:scheduleId', method: 'DELETE' } // deleteSchedule
  ]

  const column = [
    { role: 'admin' },
    { role: 'user' }
  ]

  const logicTable =
  [
    [1, 1],
    [1, 1],
    [1, 1],
    [1, 1],
    [1, 1],
    [0, 1]
  ]

  const reqRowIndex = _.findIndex(row, reqRow)
  const reqColumnIndex = _.findIndex(column, reqColumn)
  return reqRowIndex !== -1 && reqColumnIndex !== -1 ? logicTable[reqRowIndex][reqColumnIndex] : 0
}
