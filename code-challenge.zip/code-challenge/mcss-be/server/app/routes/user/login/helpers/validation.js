const validateRequest = require(`${global.SERVER_ROOT}/libs/utils/validation-util`)

module.exports = (reqBody) => {
  const schema = {
    headers: { },
    query: { $$strict: true },
    body: {
      $$strict: true,
      email: { type: 'email' },
      password: { type: 'string', min: 1 }
    }
  }
  return validateRequest(reqBody, schema)
}
