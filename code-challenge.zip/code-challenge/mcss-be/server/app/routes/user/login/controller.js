const respond = require(`${global.SERVER_ROOT}/libs/utils/response-util`) // Used for giving standardized responses
const jwt = require('jwt-simple')
const validateRequest = require('./helpers/validation')
const knexConnection = require(`${global.SERVER_ROOT}/libs/services/knex-service`)
const sha256 = require('sha256')
const userModel = require('../model')
const moment = require('moment')

module.exports = async (req, res) => {
  const knex = knexConnection()
  try {
    // step 1: validate request
    const requestParams = validateRequest(req)

    // step 2: validate user
    const user = await userModel.getUserByEmailAndPassword(knex, requestParams.email, sha256(requestParams.password))

    // step 3: create jwt
    const payload = {
      email: user.email,
      role: user.role,
      iss: user.iss,
      exp: moment().add(1, 'hour').valueOf(),
      issue: moment().valueOf()
    }

    const token = jwt.encode(payload, user.secret)

    respond.success(res, {
      email: user.email,
      name: user.name,
      role: user.role,
      jwt: token
    })
  } catch (error) { respond.failure(res, error) } finally { knex.destroy() }
}
