module.exports = {
  // create
  // retrieve
  getUserByEmailAndPassword: require('./helpers/getUserByEmailAndPassword')
  // update
  // others
}
