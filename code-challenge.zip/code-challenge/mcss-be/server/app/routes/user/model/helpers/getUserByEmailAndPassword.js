const source = 'routes_user_model_getUserByEmailAndPassword'
const { PostgresError } = require(`${global.SERVER_ROOT}/libs/utils/response-util/errortypes`)

module.exports = async (knex, email, password) => {
  try {
    const userResult = await knex
      .select()
      .from(('user'))
      .where('email', '=', email)
      .where('password', '=', password)
      .limit(1)
    if (userResult.length === 0) throw new Error('no user found or credential not matched')
    return userResult[0]
  } catch (error) {
    console.log(`source: ${source}\n ${error.stack}`)
    throw new PostgresError(error.message)
  }
}
