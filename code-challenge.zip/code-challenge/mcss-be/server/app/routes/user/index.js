// -------- Essential Packages --------
const express = require('express')
const router = express.Router({ mergeParams: true })

// -------- Controllers --------
const loginController = require('./login/controller')

// -------- API Endpoints --------
router.post('/login', loginController)
module.exports = router
