// ---- Router Config ----
const express = require('express')
const router = express.Router()

// ---- API Routes ----
const schedule = require('./schedule')
const user = require('./user')

// -------- Custom API Routes --------
router.use('/user', user)
router.use('/schedule', schedule)

module.exports = router
