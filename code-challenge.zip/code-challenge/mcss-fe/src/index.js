import React from 'react'
import ReactDOM from 'react-dom'
import { Router, Route, Switch } from 'react-router-dom'

import reportWebVitals from './reportWebVitals'
//* Components
// import App from './containers/app/App'
import Login from './containers/login'
import Home from './containers/home'

//* Utilities
import { ReduxProvider } from './utilities/redux/redux'
import browserHistory from './utilities/router/history'
import { setup } from './services'
import { Auth0Provider } from '@auth0/auth0-react'

//* Style
import './index.css'

setup()
//* Removed strictMode due to 'findDomNode' issue coming from ant design
ReactDOM.render(
  <Auth0Provider
    domain='dev-xuan.auth0.com'
    clientId='QHbpoNDiSaa6r8Ty6aa48Z4OGojgBX4n'
    redirectUri={window.location.origin}
  >
    <ReduxProvider>
      <Router history={browserHistory}>
        <Switch>
          <Route exact path='/' component={Login} />
          <Route exact path='/home' component={Home} />
        </Switch>
      </Router>
    </ReduxProvider>
  </Auth0Provider>,
  document.getElementById('root')
)

// If you want to start measuring performance in your app, pass a function
// to log results (for example: reportWebVitals(console.log))
// or send to an analytics endpoint. Learn more: https://bit.ly/CRA-vitals
reportWebVitals()
