import Axios from 'axios'

export const setup = () => {
  Axios.defaults.baseURL = process.env.REACT_APP_API_URL
  Axios.defaults.headers.common['Content-Type'] = 'application/json'
  Axios.defaults.headers.common['Cache-Control'] = 'no-store'
  Axios.defaults.headers.common.Pragma = 'no-cache'
}
setup()
