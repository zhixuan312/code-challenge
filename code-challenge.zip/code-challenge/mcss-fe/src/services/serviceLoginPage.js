import Axios from 'axios'
import { determineResponseResult, setAccessToken } from '../utilities/axios'

export const getUserDetails = (email, password) => {
  const bodyParam = {
    email,
    password
  }
  return Axios.post('/user/login', bodyParam).then(response => {
    if (response.data.status.code !== 200) {
      delete Axios.defaults.headers.common.Authorization
      throw new Error(response.data.data)
    } else return determineResponseResult(response)
  }).then(data => {
    setAccessToken(data.jwt)
    return data
  })
}
