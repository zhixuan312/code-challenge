import { Form, Input, Layout } from 'antd'
import { useDispatch } from 'react-redux'
import { useHistory } from 'react-router'
import styled from 'styled-components'

import { useStateWithPaths } from '../../utilities/hooks/useConnect'
import React, { useEffect } from 'react'
import { loginUser, updateUser } from '../../actions/actionLoginPage'
import Button from '../../components/button'
import { useAuth0 } from '@auth0/auth0-react'

const layout = {
}
const tailLayout = {
}

const StyledContent = styled.div`
font-size: 1.5em;
text-align: center;
display: flex;
justify-content: center;
align-items: center;
color: palevioletred;
`

const StyledH1 = styled.h1`
font-size: 1.5em;
text-align: center;
display: flex;
justify-content: center;
align-items: center;
color: palevioletred;
padding-bottom: 20px;
padding-top: 100px;
`

const Login = () => {
  const {
    loginWithRedirect,
    isAuthenticated,
    user,
    getAccessTokenSilently
  } = useAuth0()
  const dispatch = useDispatch()
  const history = useHistory()
  const [jwtToken = ''] = useStateWithPaths(['LoginPageReducer.user.jwt'])
  const onFinish = ({ username, password }) => { dispatch(loginUser(username, password)) }

  useEffect(() => { if (jwtToken) history.push('/home') }, [jwtToken, history])
  useEffect(() => {
    if (isAuthenticated) {
      getAccessTokenSilently().then(token => {
        const tokenStorage = {
          email: user.email,
          jwt: token,
          name: user.name,
          role: 'user'
        }
        dispatch(updateUser(tokenStorage))
        history.push('/home')
      })
    }
  }, [isAuthenticated, user, getAccessTokenSilently, history, dispatch])

  const { Header, Content } = Layout
  return (
    <Layout className='layout'>
      <StyledH1>Mario Cut Scheduling Sytem</StyledH1>
      <StyledContent className='container'>
        <Form
          {...layout}
          name='basic'
          onFinish={onFinish}
        >
          <Form.Item
            label='Username'
            name='username'
            rules={[
              {
                required: true, message: 'Please input your username!'
              }
            ]}
          >
            <Input />
          </Form.Item>

          <Form.Item
            label='Password'
            name='password'
            rules={[
              {
                required: true, message: 'Please input your password!'
              }
            ]}
          >
            <Input.Password />
          </Form.Item>

          <Form.Item {...tailLayout}>
            <Button type='primary'>
              Login
            </Button>
            <br />
            <br />
            <Button type='secondary' onClick={() => loginWithRedirect()}>
              Social Login
            </Button>
          </Form.Item>
        </Form>
      </StyledContent>
    </Layout>
  )
}

export default Login
