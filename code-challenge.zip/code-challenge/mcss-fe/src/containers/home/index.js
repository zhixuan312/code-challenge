import { Layout } from 'antd'
import React, { useEffect } from 'react'

import { useStateWithPaths } from '../../utilities/hooks/useConnect'
import Button from '../../components/button'
import { sessionLogout } from '../../utilities/router/session'
import { momentLocalizer } from 'react-big-calendar'
import moment from 'moment'
import Selectable from '../../components/calendar'

const Home = () => {
  const [jwtToken = ''] = useStateWithPaths(['LoginPageReducer.user.jwt'])
  const localizer = momentLocalizer(moment)
  useEffect(() => { if (!jwtToken) sessionLogout() }, [jwtToken])

  const { Header, Footer } = Layout
  return (
    <Layout>
      <Header>Home</Header>
      <br />
      <Selectable localizer={localizer} />
      <Footer>
        <Button
          type='destructive'
          onClick={() => sessionLogout()}
        >
          Logout
        </Button>
      </Footer>
    </Layout>
  )
}

export default Home
