import _ from 'lodash'
import { LOGIN_USER, UPDATE_USER} from '../actions/actionLoginPage'
import { setAccessToken } from '../utilities/axios'

const getDefaultState = () => {
  const token = _.get(JSON.parse(localStorage.getItem('token-storage')), 'jwt')
  if (token) setAccessToken(token)
  return { user: JSON.parse(localStorage.getItem('token-storage')) || {} }
}

// eslint-disable-next-line import/no-anonymous-default-export
export default (state = getDefaultState(), { type, payload }) => {
  switch (type) {
    case LOGIN_USER: case UPDATE_USER:
      return {
        ...state,
        user: payload
      }
    default:
      break
  }
  return state
}
