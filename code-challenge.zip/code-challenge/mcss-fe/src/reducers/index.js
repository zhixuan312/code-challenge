import { combineReducers } from 'redux'

import LoginPageReducer from './reducerLoginPage'

const rootReducer = combineReducers({
  LoginPageReducer
})
export default rootReducer
