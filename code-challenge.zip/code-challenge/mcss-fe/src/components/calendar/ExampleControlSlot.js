import createSlot from 'react-tackle-box/Slot'

export default createSlot()
