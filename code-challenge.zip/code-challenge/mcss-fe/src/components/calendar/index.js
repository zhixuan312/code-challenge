import React from 'react'
import { Calendar, Views } from 'react-big-calendar'
import events from './events'
import { PageHeader, Form, Input, Button, Select } from 'antd'
import ExampleControlSlot from './ExampleControlSlot'
import 'react-big-calendar/lib/sass/styles.scss'
import { getAllSchedule, postOneSchedule } from '../../services/serviceSchedule'
import Modal from 'react-modal'
import _ from 'lodash'

const propTypes = {}

const { Option } = Select
const layout = {
  labelCol: {
    span: 8
  },
  wrapperCol: {
    span: 16
  }
}
const tailLayout = {
  wrapperCol: {
    offset: 8,
    span: 16
  }
}

class Selectable extends React.Component {

  constructor(...args) {
    super(...args)

    this.state = { events, showModal: false, booktime:"", localEvent:[] }
    this.handleOpenModal = this.handleOpenModal.bind(this);
    this.handleCloseModal = this.handleCloseModal.bind(this);

  }

  componentDidMount() {
    this.getAllSchedule()
  }

  handleOpenModal () {
    this.setState({ showModal: true });
  }

  handleCloseModal () {
    this.setState({ showModal: false });
  }

  handleSelect = ({ start, end }) => {
    console.log(start.getFullYear(),start.getMonth(),start.getDate(),start.getHours(),end,'hello')
    let slotDate= `${start.getFullYear()}-${start.getMonth()}-${start.getDate()} ${start.getHours()}:00:00`
    this.setState({booktime: slotDate})
    this.handleOpenModal()
  }

  formRef = React.createRef();
  onFinish = (values) => {
    console.log(values, this.state.booktime);
    const email = _.get(JSON.parse(localStorage.getItem('token-storage')), 'email')
    console.log('#####' + email)
    postOneSchedule(this.state.booktime,email,values.stylist,values.activity,values.shop).then(response => {
      console.log(response,'ressult')
      this.handleCloseModal()
      this.getAllSchedule()
    })
  };
  getAllSchedule(){
    getAllSchedule().then(response => {
      console.log(response,'asdas')
     let newFormatSchedule = []
     let count = 0
     response[0].map(array=>{
       array.map(item=>{
         let date = item.date.split("-")
         let time = item.time.split(":")
         if(item.id){
           console.log(date[0], date[1], date[2], time[0], time[1],0,'start date')
           console.log(date[0], date[1], date[2], parseInt(time[0])+1, time[1],0,'end date')
           newFormatSchedule.push({
             id: count++,
             title: item.occupier + `   |   (${item.activity}@${item.shop}) | Stylist Email: ${item.stylistEmail}`,
             allDay: false,
             start: new Date(date[0], date[1], date[2], time[0], time[1],0),
             end: new Date(date[0], date[1], date[2], parseInt(time[0])+1, time[1],0),
           })
         }

       })
     })
      this.setState({localEvent:newFormatSchedule})
     })
  }
  onReset = () => {
    this.formRef.current.resetFields();
  };
  onFill = () => {
    this.formRef.current.setFieldsValue({
      note: 'Hello world!',
      gender: 'male',
    });
  };

  render() {
    const { localizer } = this.props
    return (
      <>
        <ExampleControlSlot.Entry waitForOutlet>
          <strong>
            Click an event to see more info, or drag the mouse over the calendar
            to select a date/time range.
          </strong>
        </ExampleControlSlot.Entry>
        <Modal
           isOpen={this.state.showModal}
           contentLabel="Minimal Modal Example"
        >
           <PageHeader
              className="site-page-header"
              onBack={this.handleCloseModal}
              title="Appointment Booking"
              subTitle="Please fill up the details"
            />
           <Form {...layout} ref={this.formRef} name="control-ref" onFinish={this.onFinish}>
        <Form.Item
          name="shop"
          label="Shop"
          rules={[
            {
              required: true,
            },
          ]}
        >
          {/* <Input /> */}
          <Select
            placeholder="Select a option and change input text above"
            onChange={this.onShopChange}
            allowClear
          >
            <Option value="VivoCity">VivoCity</Option>
            <Option value="Orchard ION">Orchard ION</Option>
            <Option value="Tampines Mall">Tampines Mall</Option>
            <Option value="Nex">Nex</Option>
            <Option value="Jurong Point">Jurong Point</Option>
          </Select>

        </Form.Item>
        <Form.Item
          name="activity"
          label="Activity"
          rules={[
            {
              required: true,
            },
          ]}
        >
          <Select
            placeholder="Select a option and change input text above"
            onChange={this.onActivityChange}
            allowClear
          >
            <Option value="Perm">Perm</Option>
            <Option value="Cut">Cut</Option>
            <Option value="Color">Color</Option>
            <Option value="Rebonding">Rebonding</Option>
            <Option value="Bleach">Bleach</Option>
          </Select>
        </Form.Item>
        <Form.Item
          name="stylist"
          label="Stylist"
          rules={[
            {
              required: true,
            },
          ]}
        >
          <Input />
        </Form.Item>
        <Form.Item {...tailLayout}>
          <Button type="primary" htmlType="submit">
            Book Appointment
          </Button>
          <Button htmlType="button" onClick={this.onReset}>
            Reset
          </Button>
        </Form.Item>
      </Form>

        </Modal>
        <Calendar
          selectable
          localizer={localizer}
          timeslots={1}
          step={30}
          events={this.state.localEvent}
          defaultView={Views.WEEK}
          scrollToTime={new Date(1970, 1, 1, 6)}
          defaultDate={new Date(2020, 11, 23)}
          onSelectEvent={event => alert(event.title)}
          onSelectSlot={this.handleSelect}

        />
      </>
    )
  }
}

Selectable.propTypes = propTypes

export default Selectable
