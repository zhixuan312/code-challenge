import { useState, useCallback } from 'react'

//* Used to toggle boolean state
export const useToggle = (defaultState = false) => {
  const [state, setState] = useState(defaultState)
  const toggle = useCallback(() => setState(state => !state), [])
  return [state, toggle]
}
