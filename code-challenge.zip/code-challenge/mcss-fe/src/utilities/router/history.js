import { createBrowserHistory } from 'history'

const browserHistory = createBrowserHistory({
  basename: process.env.REACT_APP_BASE_URL
})

export default browserHistory
