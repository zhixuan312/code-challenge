export const sessionLogout = () => {
  localStorage.clear()
  window.location.href = '/'
}
