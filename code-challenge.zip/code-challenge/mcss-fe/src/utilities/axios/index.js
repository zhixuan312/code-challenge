import _ from 'lodash'
import Axios from 'axios'

export const determineResponseResult = response => {
  if (_.get(response, 'status') !== 200) {
    // throw new Error(response.data.data)
  }
  return response.data.data
}

export const setAccessToken = token => {
  Axios.defaults.headers.common.Authorization = `Bearer ${token}`
}
