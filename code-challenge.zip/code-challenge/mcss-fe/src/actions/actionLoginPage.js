import { getUserDetails } from '../services/serviceLoginPage'
import { setAccessToken } from '../utilities/axios'

export const LOGIN_USER = 'LOGIN_USER'
export const loginUser = (username, password) => {
  return dispatch => {
    getUserDetails(username, password).then(response => {
      localStorage.setItem('token-storage', JSON.stringify(response) || '')
      return dispatch({ type: LOGIN_USER, payload: response })
    })
  }
}

//* If user login through authO, get the user state response from authO and update user state in redux and local storage
export const UPDATE_USER = 'UPDATE_USER'
export const updateUser = tokenStorage => {
  return dispatch => {
    localStorage.setItem('token-storage', JSON.stringify(tokenStorage) || '')
    setAccessToken(tokenStorage.jwt)
    return dispatch({
      type: UPDATE_USER,
      payload: tokenStorage
    })
  }
}
